package com.upchiapas.quem;
import com.upchiapas.quem.model.CatalogoPizza;
import com.upchiapas.quem.model.OrdenCompra;
import com.upchiapas.quem.model.Pizza;
import org.w3c.dom.ls.LSOutput;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
    public static CatalogoPizza entry = new CatalogoPizza();

    public static OrdenCompra ordenentry = new OrdenCompra();
    public static Queue<CatalogoPizza> vecCatalogo = new LinkedList<CatalogoPizza>();
    public static Queue<OrdenCompra> vecOrden = new LinkedList<OrdenCompra>();

    public static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args){
        int estado=0;
        do{
            estado=Inicio(estado);
        }while(estado!=2);
    }
    public static int Inicio(int estado){
        int i=0;
        do{
            System.out.println("Flamingos Pizza’s");
            System.out.println("1. Catalogo Pizza");
            System.out.println("2. Orden la Compra");
            System.out.println("4. salir");
            switch (teclado.nextInt()){
                case 1:{

                    do{
                        System.out.println("agregar codigo de 4 digitos de la Pizza");
                        entry.setId(teclado.nextShort());
                        System.out.println("Especialida de la Pizza");
                        entry.setEspecialidad(teclado.nextLine());
                        entry.setEspecialidad(teclado.nextLine());
                        System.out.println("agregar el precio de la pizza");
                        entry.setPrecio(teclado.nextFloat());
                        vecCatalogo.add(new CatalogoPizza(entry.getId(),entry.getEspecialidad(),entry.getPrecio()));
                        System.out.println("agregar otra pizza ? ");
                        System.out.println("1. si 2. No");
                        i=teclado.nextInt();
                    }while(i!=2);
                }break;
                case 2:{
                    OrdenPizza();
                }break;
                case 3:{

                }break;
                case 4:{
                    estado=2;
                }break;
            }
        }while(estado!=2);
        return estado;
    }
    public static void OrdenPizza(){
        int i=0;
        short id_compra = 0;
        byte piezas=0;
        float subSuma=0;

        MostrarCatalogo();
        System.out.println("codigo de la pizza");
        id_compra=teclado.nextShort();
        for (CatalogoPizza entra :vecCatalogo) {
            if(entra.getId()==id_compra){
                System.out.println("cantidad de pizzas");
                ordenentry.setCantidad(teclado.nextByte());
                subSuma=entra.getPrecio()*ordenentry.getCantidad();
                ordenentry.setSubtotal(subSuma);
                vecOrden.add(new OrdenCompra(ordenentry.getCantidad(),ordenentry.getSubtotal(),entra.getId(),entra.getEspecialidad(),entra.getPrecio()));
                System.out.println("Se encontro");}
        }
        MostrarOrden();
    }
    public static void MostrarCatalogo(){
        int i=0;
        for (CatalogoPizza entra: vecCatalogo) {
            System.out.println(entra.toString());}
    }
    public static void MostrarOrden(){
        for (OrdenCompra entra: vecOrden) {
            System.out.println(entra.toString());
        }
    }

}
